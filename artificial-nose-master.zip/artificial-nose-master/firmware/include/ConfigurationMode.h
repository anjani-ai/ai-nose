#pragma once

class Storage;

[[noreturn]] void ConfigurationMode(Storage& storage);
