#pragma once

extern const char CERT_BALTIMORE_CYBERTRUST_ROOT_CA[];
